package com.example.umesh.databasedemo;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private EditText nameEditText,ageEditText,genderEditText,idEditText;
    private Button addButton,displayButton,updateButton,deleteData;
    MyDatabaseHelper myDatabaseHelper=new MyDatabaseHelper(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SQLiteDatabase sqLiteDatabase= myDatabaseHelper.getWritableDatabase();

       nameEditText=(EditText) findViewById(R.id.etName);
       ageEditText=(EditText) findViewById(R.id.etPassword);
       genderEditText=(EditText) findViewById(R.id.etgender);
        idEditText=(EditText) findViewById(R.id.etId);
        addButton=(Button) findViewById(R.id.btnLogin);
        displayButton=(Button) findViewById(R.id.btnShow);
        updateButton=(Button) findViewById(R.id.btnUpdate);
        deleteData=(Button) findViewById(R.id.btnDelete);

        addButton.setOnClickListener(this);
        displayButton.setOnClickListener(this);
        updateButton.setOnClickListener(this);
        deleteData.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        String name=nameEditText.getText().toString();
        String age=ageEditText.getText().toString();
        String gender=genderEditText.getText().toString();
        String id=idEditText.getText().toString();

        if(v.getId()==R.id.btnLogin){
            long rowId=myDatabaseHelper.insertData(name,age,gender);
            if(rowId==-1){
                Toast.makeText(getApplicationContext(),"Row: "+rowId+" is UnSucesfully Inserted ",Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(getApplicationContext(),"Row: "+rowId+" is Sucesfully Inserted ",Toast.LENGTH_SHORT).show();
            }
        }

        if(v.getId()==R.id.btnShow){
            Cursor resultSet= myDatabaseHelper.displayAllData();
            if(resultSet.getCount()==0){
                showData("Error","No Data Found");
                return;
            }
            StringBuffer stringBuffer=new StringBuffer();
            while (resultSet.moveToNext()){
                stringBuffer.append("ID :"+resultSet.getString(0)+"\n");
                stringBuffer.append("Name :"+resultSet.getString(1)+"\n");
                stringBuffer.append("Age :"+resultSet.getString(2)+"\n");
                stringBuffer.append("Gender  :"+resultSet.getString(3)+"\n\n\n");

            }
            showData("ResultSet",stringBuffer.toString());
        }
        else if(v.getId()==R.id.btnUpdate){
                Boolean isUpdated= myDatabaseHelper.updateData(id,name,age,gender);
                if(isUpdated==true){
                    Toast.makeText(getApplicationContext(),"Data is Sucesfully Updated ",Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(getApplicationContext(),"Update Failed!",Toast.LENGTH_SHORT).show();
                }
        }
        if(v.getId()==R.id.btnDelete){
                int value=myDatabaseHelper.deleteData(id);
                if(value>0){
                    Toast.makeText(getApplicationContext(),"Data is Sucesfully Deleted ",Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(getApplicationContext(),"Data Deleted Failed! ",Toast.LENGTH_SHORT).show();
                }
        }
    }
    public void showData(String title, String data){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(data);
        builder.setCancelable(true);
        builder.show();
    }
}
